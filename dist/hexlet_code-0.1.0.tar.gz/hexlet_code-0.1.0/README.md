### Hexlet tests and linter status:
[![Actions Status](https://github.com/ofey51/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ofey51/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/af083c067b2661567aac/maintainability)](https://codeclimate.com/github/ofey51/python-project-49/maintainability)
