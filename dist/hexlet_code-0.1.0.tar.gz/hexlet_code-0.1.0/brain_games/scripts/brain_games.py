def main():
    text = '''poetry run python -m brain_games.scripts.brain_games
Welcome to the Brain Games!'''
    print(text)
    additional_info = ""

if __name__ == "__main__":
    main()
